#include <iostream>
#include "Agency.h"

using namespace std;

int main(){
	Agency *agency = new Agency();

}
